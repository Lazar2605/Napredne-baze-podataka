﻿namespace NBPProj1_2.Models
{
    public class Usluga
    {
        public int ID { get; set; }
        public int salonID { get; set; }
        public string Naziv { get; set; }
        public int Cena { get; set; }
    }
}
