﻿namespace NBPProj1_2.Models
{
    public class Frizer
    {
        public int ID { get; set; }
        public string Ime { get; set; }
        public string Prezime { get; set; }
        public int idSalona { get; set; }
    }
}
