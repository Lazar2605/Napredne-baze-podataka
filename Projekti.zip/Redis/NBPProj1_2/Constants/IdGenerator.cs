﻿namespace NBPProj1_2.Constants
{
    public class IdGenerator
    {
        public const string SalonIdGenerator = "SalonIdCounter";
    }
}
