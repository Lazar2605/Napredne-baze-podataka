﻿namespace NBPProj1_2.Constants
{
    public class Constatns
    {
        public const string SalonsSortedSetKey = "SalonsSortedSetKey";

        public const string ReservationListKey = "ReservationListKey";
    }
}
