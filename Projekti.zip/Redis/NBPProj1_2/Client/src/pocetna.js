import { Logovanje } from "./logovanje.js";

var g = new Logovanje(document.body);
g.Crtaj();