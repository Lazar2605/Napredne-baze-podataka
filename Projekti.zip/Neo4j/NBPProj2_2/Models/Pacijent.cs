﻿namespace NBPProj2_2.Models
{
    public class Pacijent : Osoba
    {
        public string BrojZdravstveneKnjizice { get; set; }
        public int BrojKartona { get; set; }
    }
}
