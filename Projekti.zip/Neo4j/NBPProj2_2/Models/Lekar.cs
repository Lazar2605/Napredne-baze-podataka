﻿namespace NBPProj2_2.Models
{
    public class Lekar : Osoba
    {
        public string BrojTelefona { get; set; }
        public string Specijalnost { get; set; }
        public int BrojKancelarije { get; set; }
    }
}
