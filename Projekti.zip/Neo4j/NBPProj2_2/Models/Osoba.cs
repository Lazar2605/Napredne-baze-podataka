﻿namespace NBPProj2_2.Models
{
    public class Osoba
    {
        public string Ime { get; set; }
        public string SrednjeSlovo { get; set; }
        public string Prezime { get; set; }
        public string Pol { get; set; }
        public string DatumRodjenja { get; set; }
        public string JMBG { get; set; }
        public string BrojLicneKarte { get; set; }
    }
}
