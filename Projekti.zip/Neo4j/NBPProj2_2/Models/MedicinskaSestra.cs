﻿namespace NBPProj2_2.Models
{
    public class MedicinskaSestra : Osoba
    {
        public string BrojTelefona { get; set; }
    }
}
