﻿namespace NBPProj2_2.Models
{
    public class Pregled
    {
        public string DatumPregleda { get; set; }
        public string Razlog { get; set; }
        public string Dijagnoza { get; set; }
        public string Lekar { get; set; }
    }
}
